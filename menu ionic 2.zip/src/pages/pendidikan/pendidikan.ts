import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-pendidikan',
  templateUrl: 'pendidikan.html'
})
export class Pendidikan {
}

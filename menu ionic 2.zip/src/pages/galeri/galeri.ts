import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

@Component({
  selector: 'page-galeri',
  templateUrl: 'galeri.html'
})
export class Galeri {
}
